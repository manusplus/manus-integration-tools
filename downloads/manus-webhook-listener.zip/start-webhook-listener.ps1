$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $Root

Write-Host "Manus Webhook Listener" -ForegroundColor Cyan
Write-Host "======================"

if (-not (Get-Command node -ErrorAction SilentlyContinue)) {
    Write-Host "Node.js is not installed. Install Node.js LTS and run this script again." -ForegroundColor Red
    Start-Process "https://nodejs.org/"
    Read-Host "Press Enter to close"
    exit 1
}

if (-not (Test-Path (Join-Path $Root "node_modules"))) {
    Write-Host "Installing dependencies..."
    npm install
    if ($LASTEXITCODE -ne 0) { throw "npm install failed." }
}

Write-Host "Starting the listener at http://localhost:3000 ..." -ForegroundColor Green
Write-Host "Start ngrok in a second PowerShell window with: ngrok http 3000" -ForegroundColor Yellow
Write-Host "First-time ngrok setup: ngrok config add-authtoken YOUR_TOKEN" -ForegroundColor Yellow
Start-Process "http://localhost:3000"
node .\manus-webhook-listener.js
