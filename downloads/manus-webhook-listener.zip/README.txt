MANUS WEBHOOK LISTENER

1. Install Node.js LTS if it is not already installed.
2. Create your own ngrok account.
3. Configure ngrok once:
   ngrok config add-authtoken YOUR_TOKEN
4. Run start-webhook-listener.ps1.
5. In a second PowerShell window run:
   ngrok http 3000
6. Use the HTTPS ngrok URL plus /webhook as the subscriber URL.

Local dashboard: http://localhost:3000
ngrok inspection: http://127.0.0.1:4040
