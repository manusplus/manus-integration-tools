const express = require('express');
const app = express();
const PORT = 3000;

// Store received data for inspection
let receivedWebhooks = [];
let manualTunnelUrl = null;

// Parse JSON BEFORE logging middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Enhanced logging middleware
app.use((req, res, next) => {
    const timestamp = new Date().toISOString();

    const isWebhookRequest =
        req.path === '/webhook' ||
        req.headers['x-hook-secret'];

    if (isWebhookRequest) {
        console.log(`\n📡 ${req.method} ${req.path} - ${timestamp}`);
    }

    next();
});

// Verification handler function
const handleVerification = (req, res) => {
    console.log('\n' + '='.repeat(80));
    console.log('🔐 WEBHOOK VERIFICATION REQUEST');
    console.log('='.repeat(80));

    const hookSecret = req.headers['x-hook-secret'];
    const timestamp = new Date().toISOString();

    if (hookSecret) {
        console.log(`✅ X-Hook-Secret found: "${hookSecret}"`);

        receivedWebhooks.push({
            timestamp,
            type: 'verification',
            method: req.method,
            path: req.path,
            verified: true,
            message: 'X-Hook-Secret received and returned successfully',
            sourceIp:
                req.headers['x-forwarded-for'] ||
                req.socket.remoteAddress
        });

        res.set('X-Hook-Secret', hookSecret);
        res.status(200).send('Webhook verification successful');

        console.log('🎉 Verification completed successfully!');
    } else {
        receivedWebhooks.push({
            timestamp,
            type: 'verification',
            method: req.method,
            path: req.path,
            verified: false,
            message: 'Missing X-Hook-Secret header',
            sourceIp:
                req.headers['x-forwarded-for'] ||
                req.socket.remoteAddress
        });

        console.log('❌ Missing X-Hook-Secret header');
        res.status(400).send('Missing X-Hook-Secret header');
    }

    console.log('='.repeat(80) + '\n');
};

// Root path handler
app.get('/', (req, res) => {
    if (req.headers['x-hook-secret']) {
        return handleVerification(req, res);
    }
    
    const html = `
    <!DOCTYPE html>
    <html>
    <head>
        <title>Webhook Test Dashboard</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <style>
            * { margin: 0; padding: 0; box-sizing: border-box; }
            body { 
                font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, sans-serif;
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                min-height: 100vh;
                padding: 20px;
            }
            .container { 
                max-width: 1200px; 
                margin: 0 auto; 
                background: white; 
                padding: 30px; 
                border-radius: 16px;
                box-shadow: 0 20px 60px rgba(0,0,0,0.3);
            }
            h1 { 
                color: #333; 
                margin-bottom: 10px;
                font-size: 2em;
            }
            .subtitle {
                color: #666;
                margin-bottom: 30px;
                font-size: 1.1em;
            }
            .stats { 
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                color: white;
                padding: 20px; 
                border-radius: 12px; 
                margin: 20px 0;
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
                gap: 20px;
            }
            .stat-item {
                text-align: center;
            }
            .stat-number {
                font-size: 2.5em;
                font-weight: bold;
                margin-bottom: 5px;
            }
            .stat-label {
                font-size: 0.9em;
                opacity: 0.9;
            }
            .tunnel-info {
                background: #f0f9ff;
                border-left: 4px solid #0ea5e9;
                padding: 15px;
                border-radius: 8px;
                margin: 20px 0;
            }
            .tunnel-url {
                font-family: 'Courier New', monospace;
                font-size: 1.1em;
                color: #0369a1;
                word-break: break-all;
                margin-top: 5px;
            }
            .setup-box {
                background: #fef3c7;
                border-left: 4px solid #f59e0b;
                padding: 15px;
                border-radius: 8px;
                margin: 20px 0;
            }
            .setup-box code {
                background: #fff;
                padding: 2px 6px;
                border-radius: 4px;
                font-family: 'Courier New', monospace;
                font-size: 0.9em;
            }
            .webhook { 
                border: 1px solid #e5e7eb; 
                margin: 15px 0; 
                padding: 20px; 
                border-radius: 12px; 
                background: #fafafa;
                transition: transform 0.2s, box-shadow 0.2s;
            }
            .webhook:hover {
                transform: translateY(-2px);
                box-shadow: 0 4px 12px rgba(0,0,0,0.1);
            }
            .timestamp { 
                color: #6b7280; 
                font-size: 0.9em; 
                margin-bottom: 10px;
                display: flex;
                align-items: center;
                gap: 5px;
            }
            .method-badge {
                display: inline-block;
                padding: 4px 12px;
                border-radius: 20px;
                font-size: 0.85em;
                font-weight: 600;
                margin-right: 10px;
            }
            .method-POST {
                background: #dcfce7;
                color: #166534;
            }
            .method-GET {
                background: #dbeafe;
                color: #1e40af;
            }
            pre { 
                background: #1f2937; 
                color: #f9fafb;
                padding: 15px; 
                overflow-x: auto; 
                border-radius: 8px;
                font-size: 0.9em;
                margin-top: 10px;
                max-height: 400px;
            }
            .no-webhooks {
                text-align: center;
                padding: 60px 20px;
                color: #9ca3af;
            }
            .no-webhooks-icon {
                font-size: 4em;
                margin-bottom: 20px;
            }
            h2 { 
                color: #1f2937; 
                margin: 30px 0 15px 0;
                font-size: 1.5em;
                border-bottom: 2px solid #e5e7eb;
                padding-bottom: 10px;
            }
            .info-box {
                background: #e0f2fe;
                border-left: 4px solid #0ea5e9;
                padding: 15px;
                border-radius: 8px;
                margin: 20px 0;
            }
            .auto-refresh {
                text-align: center;
                color: #6b7280;
                font-size: 0.9em;
                margin-top: 30px;
                padding: 10px;
                background: #f9fafb;
                border-radius: 8px;
            }
            .command-box {
                background: #1f2937;
                color: #f9fafb;
                padding: 12px;
                border-radius: 6px;
                font-family: 'Courier New', monospace;
                margin: 10px 0;
                font-size: 0.95em;
            }
            .activity-toolbar {
                display: flex;
                gap: 8px;
                flex-wrap: wrap;
                align-items: center;
                margin: 0 0 15px 0;
            }
            .activity-limit-label {
                display: inline-flex;
                align-items: center;
                gap: 8px;
                margin-left: auto;
                color: #4b5563;
                font-weight: 600;
            }
            .activity-limit {
                width: auto;
                min-width: 90px;
                border: 1px solid #d1d5db;
                background: white;
                color: #374151;
                padding: 8px 10px;
                border-radius: 8px;
                font-weight: 600;
            }
            .activity-clear {
                border: 1px solid #fecaca;
                background: #fff;
                color: #b91c1c;
                padding: 8px 14px;
                border-radius: 8px;
                cursor: pointer;
                font-weight: 600;
            }
            .activity-clear:hover {
                background: #fef2f2;
            }
            .activity-filter {
                border: 1px solid #d1d5db;
                background: white;
                color: #374151;
                padding: 8px 14px;
                border-radius: 999px;
                cursor: pointer;
                font-weight: 600;
            }
            .activity-filter.active {
                background: #4f46e5;
                border-color: #4f46e5;
                color: white;
            }
            .activity-empty {
                display: none;
                text-align: center;
                padding: 30px 20px;
                color: #9ca3af;
                border: 1px dashed #d1d5db;
                border-radius: 12px;
            }
            .verification-card {
                margin-top: 10px;
                padding: 10px 12px;
                border-radius: 8px;
            }
            .verification-meta {
                display: flex;
                gap: 18px;
                flex-wrap: wrap;
                margin-top: 8px;
                font-size: 0.9em;
            }
        </style>
    </head>
    <body>
        <div class="container">
            <h1>📡 Webhook Dashboard</h1>
            <div class="subtitle">Real-time webhook monitoring</div>
            
            ${!manualTunnelUrl ? `
            <div class="setup-box">
                <strong>⚠️ Setup Required:</strong><br>
                Open a second terminal and run ngrok to fetch subscriber URL:<br><br>
                              
                <strong>🟢 ngrok</strong>
                <div class="command-box">ngrok http 3000</div>
                <small>ngrok <a href="http://127.0.0.1:4040" target="_blank">http://127.0.0.1:4040</a> also has a dashboard!</small>
            </div>
            ` : `
            <div class="tunnel-info">
                <strong>🌐 Your Public URL:</strong>
                <div class="tunnel-url">${manualTunnelUrl}</div>
            </div>
            `}
            
            <div class="stats">
                <div class="stat-item">
                    <div class="stat-number">${receivedWebhooks.filter(w => w.type !== 'verification').length}</div>
                    <div class="stat-label">Notifications</div>
                </div>
                <div class="stat-item">
                    <div class="stat-number">${receivedWebhooks.filter(w => w.type === 'verification').length}</div>
                    <div class="stat-label">Verification Requests</div>
                </div>
                <div class="stat-item">
                    <div class="stat-number">${receivedWebhooks.length}</div>
                    <div class="stat-label">Total Activity</div>
                </div>
            </div>          
            
            
            <h2>📨 Webhook Activity</h2>
            <div class="activity-toolbar" aria-label="Webhook activity filter">
                <button type="button" class="activity-filter active" data-filter="all">All</button>
                <button type="button" class="activity-filter" data-filter="verification">Verifications</button>
                <button type="button" class="activity-filter" data-filter="notification">Notifications</button>
                <label class="activity-limit-label" for="activityLimit">
                    Show
                    <select id="activityLimit" class="activity-limit">
                        <option value="10">10</option>
                        <option value="25">25</option>
                        <option value="50">50</option>
                        <option value="100">100</option>
                        <option value="all">All</option>
                    </select>
                </label>
                <button type="button" id="clearActivity" class="activity-clear">Clear Activity</button>
            </div>

            <div id="activityList">
            ${receivedWebhooks.length > 0 ? receivedWebhooks.slice().reverse().map(webhook => `
                <div class="webhook activity-item" data-activity-type="${webhook.type === 'verification' ? 'verification' : 'notification'}">
                    <div class="timestamp">
                        ⏰ ${webhook.timestamp}
                    </div>
                    <div>
                        <span class="method-badge method-${webhook.method || 'POST'}">${webhook.method || 'POST'}</span>
                        <strong>${webhook.type === 'verification' ? 'Subscriber Verification' : 'Webhook Notification'}</strong>
                        <span style="margin-left:8px;color:#6b7280;">${webhook.path || '/'}</span>
                    </div>
                    ${webhook.type === 'verification' ? `
                        <div class="verification-card" style="
                            background:${webhook.verified ? '#dbeafe' : '#fee2e2'};
                            color:${webhook.verified ? '#1e40af' : '#991b1b'};
                        ">
                            <div style="font-weight:700;">
                                ${webhook.verified
                                    ? '🔵 Subscriber verification successful'
                                    : '❌ Subscriber verification failed'}
                            </div>
                            <div class="verification-meta">
                                <span><strong>Message:</strong> ${webhook.message}</span>
                                <span><strong>Source IP:</strong> ${webhook.sourceIp || 'Unknown'}</span>
                            </div>
                        </div>
                    ` : `
                        <div style="
                            display:grid;
                            grid-template-columns:repeat(auto-fit, minmax(320px, 1fr));
                            gap:12px;
                            margin-top:10px;
                        ">
                            <div>
                                <strong>📦 Payload:</strong>
                                ${
                                    webhook.body && Object.keys(webhook.body).length > 0
                                        ? `<pre>${JSON.stringify(webhook.body, null, 2)}</pre>`
                                        : `<div style="margin-top:10px;color:#9ca3af;"><em>No body data</em></div>`
                                }
                            </div>
                            <div>
                                <strong>📋 Headers:</strong>
                                ${
                                    webhook.headers && Object.keys(webhook.headers).length > 0
                                        ? `<pre>${JSON.stringify(webhook.headers, null, 2)}</pre>`
                                        : `<div style="margin-top:10px;color:#9ca3af;"><em>No header data</em></div>`
                                }
                            </div>
                        </div>
                    `}
                </div>
            `).join('') : `
                <div class="no-webhooks">
                    <div class="no-webhooks-icon">📭</div>
                    <h3>No activity received yet</h3>
                    <p style="margin-top: 10px;">Waiting for subscriber verification or webhook notifications...</p>
                    <p style="margin-top: 5px; font-size: 0.9em;">Make sure the listener and tunnel are running.</p>
                </div>
            `}
            </div>
            <div id="activityFilterEmpty" class="activity-empty">No activity matches this filter.</div>

            <div class="auto-refresh">
                🔄 Auto-refreshing every 5 seconds...
            </div>
        </div>
        
        <script>
            const FILTER_STORAGE_KEY = 'webhook-dashboard-activity-filter';
            const LIMIT_STORAGE_KEY = 'webhook-dashboard-activity-limit';
            const filterButtons = Array.from(document.querySelectorAll('.activity-filter'));
            const activityItems = Array.from(document.querySelectorAll('.activity-item'));
            const filterEmpty = document.getElementById('activityFilterEmpty');
            const activityLimit = document.getElementById('activityLimit');
            const clearActivity = document.getElementById('clearActivity');

            function getSelectedLimit() {
                const raw = activityLimit ? activityLimit.value : '10';
                return raw === 'all' ? Infinity : Number(raw || 10);
            }

            function applyActivityFilter(filter) {
                const normalized = ['all', 'verification', 'notification'].includes(filter) ? filter : 'all';
                const limit = getSelectedLimit();
                let shown = 0;

                filterButtons.forEach(button => {
                    button.classList.toggle('active', button.dataset.filter === normalized);
                });

                activityItems.forEach(item => {
                    const matches = normalized === 'all' || item.dataset.activityType === normalized;
                    const visible = matches && shown < limit;
                    item.style.display = visible ? '' : 'none';
                    if (visible) shown++;
                });

                if (filterEmpty) {
                    filterEmpty.style.display = activityItems.length > 0 && shown === 0 ? 'block' : 'none';
                }

                localStorage.setItem(FILTER_STORAGE_KEY, normalized);
            }

            filterButtons.forEach(button => {
                button.addEventListener('click', () => applyActivityFilter(button.dataset.filter));
            });

            if (activityLimit) {
                const rememberedLimit = localStorage.getItem(LIMIT_STORAGE_KEY) || '10';
                activityLimit.value = ['10', '25', '50', '100', 'all'].includes(rememberedLimit)
                    ? rememberedLimit
                    : '10';
                activityLimit.addEventListener('change', () => {
                    localStorage.setItem(LIMIT_STORAGE_KEY, activityLimit.value);
                    applyActivityFilter(localStorage.getItem(FILTER_STORAGE_KEY) || 'all');
                });
            }

            if (clearActivity) {
                clearActivity.addEventListener('click', async () => {
                    if (!confirm('Clear all webhook activity from this listener session?')) return;
                    clearActivity.disabled = true;
                    try {
                        const response = await fetch('/clear-activity', { method: 'POST' });
                        if (!response.ok) throw new Error('HTTP ' + response.status);
                        location.reload();
                    } catch (error) {
                        clearActivity.disabled = false;
                        alert('Could not clear activity: ' + (error.message || error));
                    }
                });
            }

            applyActivityFilter(localStorage.getItem(FILTER_STORAGE_KEY) || 'all');
            setTimeout(() => location.reload(), 5000);
        </script>
    </body>
    </html>`;
    
    res.send(html);
});

// Handle POST requests to root path
app.post('/', (req, res) => {
    console.log('\n' + '='.repeat(80));
    console.log('📨 WEBHOOK NOTIFICATION RECEIVED');
    console.log('='.repeat(80));
    console.log(`📅 Timestamp: ${new Date().toISOString()}`);
    
    console.log('\n📦 WEBHOOK PAYLOAD:');
    console.log(JSON.stringify(req.body, null, 2));
	
	console.log('\n📋 REQUEST HEADERS:');
	console.log(JSON.stringify(req.headers, null, 2));
    
    // Store the webhook data
    const webhookData = {
        timestamp: new Date().toISOString(),
        method: 'POST',
        path: req.path,
        headers: req.headers,
        body: req.body,
        sourceIp: req.headers['x-forwarded-for'] || req.connection.remoteAddress
    };
    
    receivedWebhooks.push(webhookData);
    
    // Process the notification
    if (req.body && req.body.Topic) {
        console.log(`\n🔍 PARSED DATA:`);
        console.log(`   🎯 Event Type: "${req.body.Topic}"`);
        console.log(`   🏢 Node ID: "${req.body.Node}"`);
        console.log(`   🎯 Target ID: "${req.body.Target}"`);
        if (req.body.Employee) {
            console.log(`   👤 Employee ID: "${req.body.Employee}"`);
        }
    }
    
    res.status(200).json({ 
        status: 'received', 
        message: 'Webhook processed successfully',
        timestamp: new Date().toISOString()
    });
    
    console.log('\n🎉 WEBHOOK PROCESSED!');
    console.log('='.repeat(80) + '\n');
});

// Webhook endpoints (alternative paths)
app.get('/webhook', handleVerification);

app.post('/webhook', (req, res) => {
    console.log('\n📨 WEBHOOK at /webhook');
    console.log('Payload:', JSON.stringify(req.body, null, 2));
    
    receivedWebhooks.push({
        timestamp: new Date().toISOString(),
        method: 'POST',
        path: '/webhook',
        headers: req.headers,
        body: req.body
    });
    
    res.status(200).json({ 
        status: 'received', 
        message: 'Webhook processed successfully' 
    });
});

// Clear in-memory activity history
app.post('/clear-activity', (req, res) => {
    const cleared = receivedWebhooks.length;
    receivedWebhooks = [];
    res.status(200).json({
        status: 'cleared',
        cleared
    });
});

// Test ping endpoint
app.get('/ping-test', (req, res) => {
    res.json({
        status: 'Server is running',
        timestamp: new Date().toISOString(),
        url: req.get('host')
    });
});

// Catch-all route
app.use((req, res) => {
    console.log('\n🚨 CATCH-ALL ROUTE HIT');
    console.log(`Method: ${req.method}`);
    console.log(`Path: ${req.path}`);
    if (req.body && Object.keys(req.body).length > 0) {
        console.log('Body:', JSON.stringify(req.body, null, 2));
    }
    
    receivedWebhooks.push({
        timestamp: new Date().toISOString(),
        method: req.method,
        path: req.path,
        headers: req.headers,
        body: req.body
    });
    
    res.status(200).json({
        message: 'Request captured',
        method: req.method,
        path: req.path
    });
});

// Start server
app.listen(PORT, () => {
    console.log('\n' + '='.repeat(60));
    console.log('🚀 Webhook Test Server Running!');
    console.log('='.repeat(60));
    console.log(`\n📊 Local Dashboard: http://localhost:${PORT}`);
    console.log(`\n📋 Next Steps:`);
    console.log('\n1️⃣  Open a SECOND terminal and run ONE of these:\n');
    
    console.log('   🔵 LocalTunnel (same URL each time):');
    console.log('   ─────────────────────────────────────');
    console.log('   npx localtunnel --port 3000 --subdomain your-unique-name');
    console.log('   Example: npx localtunnel --port 3000 --subdomain jeroen-manus-webhook\n');
    
    console.log('   🟢 ngrok (best dashboard):');
    console.log('   ─────────────────────────────────────');
    console.log('   ngrok http 3000 or npx ngrok http 3000 (no installation)');
    console.log('   Then visit: http://127.0.0.1:4040 (ngrok web dashboard)');
	console.log('   First time? Use Global install:	npm install -g ngrok');
    
    console.log('\n2️⃣  Copy the tunnel URL from the second terminal');
    console.log('3️⃣  Register that URL as your webhook endpoint');
    console.log('4️⃣  Test by triggering events in your system');
    
    console.log('\n🔍 Watching for webhooks...\n');
    console.log('='.repeat(60) + '\n');
});