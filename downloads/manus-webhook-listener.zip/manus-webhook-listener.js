const express = require('express');
const app = express();
const PORT = 3000;

// Store received data for inspection
let receivedWebhooks = [];

// Parse JSON BEFORE logging middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Enhanced logging middleware
app.use((req, res, next) => {
    const timestamp = new Date().toISOString();

    const isWebhookRequest =
        req.path === '/webhook' ||
        req.headers['x-hook-secret'];

    if (isWebhookRequest) {
        console.log(`\n📡 ${req.method} ${req.path} - ${timestamp}`);
    }

    next();
});


function maskHookSecret(value) {
    const text = String(value || '');
    if (!text) return '';
    return text.slice(0, 3) + '***';
}

function maskVerificationHeaders(headers) {
    const masked = { ...(headers || {}) };
    for (const key of Object.keys(masked)) {
        if (key.toLowerCase() === 'x-hook-secret') {
            masked[key] = maskHookSecret(masked[key]);
        }
    }
    return masked;
}

function escapeDashboardHtml(value) {
    return String(value == null ? '' : value)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#39;');
}

function formatHttpHeaders(headers) {
    return Object.entries(headers || {})
        .map(([key, value]) => `${key}: ${Array.isArray(value) ? value.join(', ') : value}`)
        .join('\n');
}

function getSubscriberEndpoint(request, webhook) {
    const headers = (request && request.headers) || {};
    const protocol = headers['x-forwarded-proto'] || 'https';
    const host = headers['x-forwarded-host'] || headers.host || 'localhost';
    const path = (request && request.path) || webhook.path || '/';
    return `${protocol}://${host}${path}`;
}

function formatActivityRequest(webhook) {
    const request = webhook.request || {
        method: webhook.method,
        path: webhook.path,
        headers: webhook.headers,
        body: webhook.body
    };
    const headers = webhook.type === 'verification'
        ? maskVerificationHeaders(request.headers || {})
        : { ...(request.headers || {}) };
    const requestLine = `${request.method || webhook.method || 'GET'} ${getSubscriberEndpoint(request, webhook)}`;
    const headerText = formatHttpHeaders(headers);
    const body = request.body;
    const bodyText = body && typeof body === 'object' && Object.keys(body).length > 0
        ? JSON.stringify(body, null, 2)
        : '';
    return requestLine +
        (headerText ? `

Headers
${headerText}` : '') +
        (bodyText ? `

Payload
${bodyText}` : '');
}

function formatActivityResponse(webhook) {
    const response = webhook.response || {};
    const status = response.status || (webhook.verified === false ? 400 : 200);
    const statusText = response.statusText || (status === 200 ? 'OK' : 'Bad Request');
    const headers = webhook.type === 'verification'
        ? maskVerificationHeaders(response.headers || {})
        : { ...(response.headers || {}) };
    const headerText = formatHttpHeaders(headers);
    const rawBody = response.body;
    const body = rawBody && typeof rawBody === 'object'
        ? JSON.stringify(rawBody, null, 2)
        : String(rawBody || '');
    return `${status} ${statusText}` +
        (headerText ? `

Headers
${headerText}` : '') +
        (body ? `

Body
${body}` : '');
}


function getActivityStats() {
    return {
        notifications: receivedWebhooks.filter(item => item.type !== 'verification').length,
        verifications: receivedWebhooks.filter(item => item.type === 'verification').length,
        total: receivedWebhooks.length
    };
}

function getActivitySignature() {
    const latest = receivedWebhooks.length
        ? receivedWebhooks[receivedWebhooks.length - 1].timestamp
        : '';
    return `<span id="totalActivityCount">${getActivityStats().total}</span>:${latest}`;
}


async function getNgrokStatus() {
    try {
        const response = await fetch('http://127.0.0.1:4040/api/tunnels');
        if (!response.ok) throw new Error(`HTTP ${response.status}`);

        const data = await response.json();
        const tunnels = Array.isArray(data.tunnels) ? data.tunnels : [];
        const tunnel = tunnels.find(item => item && item.proto === 'https');

        return {
            running: Boolean(tunnel),
            publicUrl: tunnel && tunnel.public_url ? String(tunnel.public_url) : null,
            dashboardUrl: 'http://127.0.0.1:4040'
        };
    } catch (error) {
        return {
            running: false,
            publicUrl: null,
            dashboardUrl: 'http://127.0.0.1:4040'
        };
    }
}

function renderActivityHtml() {
    if (!receivedWebhooks.length) {
        return `
            <div class="no-webhooks">
                <div class="no-webhooks-icon">📭</div>
                <h3>No activity received yet</h3>
                <p style="margin-top:10px;">Waiting for subscriber verification or webhook notifications...</p>
                <p style="margin-top:5px;font-size:0.9em;">Make sure the listener and tunnel are running.</p>
            </div>`;
    }

    return receivedWebhooks.slice().reverse().map(webhook => `
        <div class="webhook activity-item ${webhook.type === 'verification' ? 'verification-flow' : 'notification-flow'}"
             data-activity-type="${webhook.type === 'verification' ? 'verification' : 'notification'}">
            <div class="timestamp">⏰ ${escapeDashboardHtml(webhook.timestamp)}</div>
            <div>
                <span class="method-badge method-${webhook.method || 'POST'}">${escapeDashboardHtml(webhook.method || 'POST')}</span>
                <strong>${webhook.type === 'verification' ? 'Subscriber Verification' : 'Webhook Notification'}</strong>
            </div>
            <div class="flow-banner ${webhook.type === 'verification' ? 'verification' : 'notification'}">
                ${webhook.type === 'verification'
                    ? (webhook.verified ? '🔵 Verification request and subscriber response' : '❌ Subscriber verification failed')
                    : '🟢 Notification request and subscriber response'}
                <span class="flow-source"><strong>Source IP:</strong> ${escapeDashboardHtml(webhook.sourceIp || 'Unknown')}</span>
            </div>
            <div class="exchange-grid">
                <div class="exchange-column">
                    <strong>➡️ Incoming Request:</strong>
                    <pre>${escapeDashboardHtml(formatActivityRequest(webhook))}</pre>
                </div>
                <div class="exchange-column">
                    <strong>⬅️ Subscriber Response:</strong>
                    <pre>${escapeDashboardHtml(formatActivityResponse(webhook))}</pre>
                </div>
            </div>
        </div>
    `).join('');
}

// Verification handler function
const handleVerification = (req, res) => {
    console.log('\n' + '='.repeat(80));
    console.log('🔐 WEBHOOK VERIFICATION REQUEST');
    console.log('='.repeat(80));

    const hookSecret = req.headers['x-hook-secret'];
    const timestamp = new Date().toISOString();

    if (hookSecret) {
        console.log(`✅ X-Hook-Secret found: "${hookSecret}"`);

        receivedWebhooks.push({
            timestamp,
            type: 'verification',
            method: req.method,
            path: req.originalUrl || req.path,
            verified: true,
            request: {
                method: req.method,
                path: req.originalUrl || req.path,
                headers: { ...req.headers }
            },
            response: {
                status: 200,
                statusText: 'OK',
                headers: {
                    'X-Hook-Secret': hookSecret,
                    'Content-Type': 'text/html; charset=utf-8'
                },
                body: 'Webhook verification successful'
            },
            sourceIp:
                req.headers['x-forwarded-for'] ||
                req.socket.remoteAddress
        });

        res.set('X-Hook-Secret', hookSecret);
        res.status(200).send('Webhook verification successful');

        console.log('🎉 Verification completed successfully!');
    } else {
        receivedWebhooks.push({
            timestamp,
            type: 'verification',
            method: req.method,
            path: req.originalUrl || req.path,
            verified: false,
            request: {
                method: req.method,
                path: req.originalUrl || req.path,
                headers: { ...req.headers }
            },
            response: {
                status: 400,
                statusText: 'Bad Request',
                headers: {
                    'Content-Type': 'text/html; charset=utf-8'
                },
                body: 'Missing X-Hook-Secret header'
            },
            sourceIp:
                req.headers['x-forwarded-for'] ||
                req.socket.remoteAddress
        });

        console.log('❌ Missing X-Hook-Secret header');
        res.status(400).send('Missing X-Hook-Secret header');
    }

    console.log('='.repeat(80) + '\n');
};

// Root path handler
app.get('/', (req, res) => {
    if (req.headers['x-hook-secret']) {
        return handleVerification(req, res);
    }
    
    const html = `
    <!DOCTYPE html>
    <html>
    <head>
        <title>Webhook Test Dashboard</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <style>
            * { margin: 0; padding: 0; box-sizing: border-box; }
            body { 
                font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, sans-serif;
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                min-height: 100vh;
                padding: 20px;
            }
            .container { 
                max-width: 1200px; 
                margin: 0 auto; 
                background: white; 
                padding: 30px; 
                border-radius: 16px;
                box-shadow: 0 20px 60px rgba(0,0,0,0.3);
            }
            h1 { 
                color: #333; 
                margin-bottom: 10px;
                font-size: 2em;
            }
            .subtitle {
                color: #666;
                margin-bottom: 30px;
                font-size: 1.1em;
            }
            .stats { 
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                color: white;
                padding: 20px; 
                border-radius: 12px; 
                margin: 20px 0;
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
                gap: 20px;
            }
            .stat-item {
                text-align: center;
            }
            .stat-number {
                font-size: 2.5em;
                font-weight: bold;
                margin-bottom: 5px;
            }
            .stat-label {
                font-size: 0.9em;
                opacity: 0.9;
            }
            .tunnel-info {
                background: #f0f9ff;
                border-left: 4px solid #0ea5e9;
                padding: 15px;
                border-radius: 8px;
                margin: 20px 0;
            }
            .tunnel-url {
                font-family: 'Courier New', monospace;
                font-size: 1.1em;
                color: #0369a1;
                word-break: break-all;
                margin-top: 5px;
            }
            .setup-box {
                background: #fef3c7;
                border-left: 4px solid #f59e0b;
                padding: 15px;
                border-radius: 8px;
                margin: 20px 0;
            }
            .setup-box code {
                background: #fff;
                padding: 2px 6px;
                border-radius: 4px;
                font-family: 'Courier New', monospace;
                font-size: 0.9em;
            }
            .webhook { 
                border: 1px solid #e5e7eb; 
                margin: 15px 0; 
                padding: 20px; 
                border-radius: 12px; 
                background: #fafafa;
                transition: transform 0.2s, box-shadow 0.2s;
            }
            .webhook:hover {
                transform: translateY(-2px);
                box-shadow: 0 4px 12px rgba(0,0,0,0.1);
            }
            .timestamp { 
                color: #6b7280; 
                font-size: 0.9em; 
                margin-bottom: 10px;
                display: flex;
                align-items: center;
                gap: 5px;
            }
            .method-badge {
                display: inline-block;
                padding: 4px 12px;
                border-radius: 20px;
                font-size: 0.85em;
                font-weight: 600;
                margin-right: 10px;
            }
            .method-POST {
                background: #dcfce7;
                color: #166534;
            }
            .method-GET {
                background: #dbeafe;
                color: #1e40af;
            }
            pre { 
                background: #1f2937; 
                color: #f9fafb;
                padding: 15px; 
                overflow-x: auto; 
                border-radius: 8px;
                font-size: 0.9em;
                margin-top: 10px;
                max-height: 400px;
            }
            .no-webhooks {
                text-align: center;
                padding: 60px 20px;
                color: #9ca3af;
            }
            .no-webhooks-icon {
                font-size: 4em;
                margin-bottom: 20px;
            }
            h2 { 
                color: #1f2937; 
                margin: 30px 0 15px 0;
                font-size: 1.5em;
                border-bottom: 2px solid #e5e7eb;
                padding-bottom: 10px;
            }
            .info-box {
                background: #e0f2fe;
                border-left: 4px solid #0ea5e9;
                padding: 15px;
                border-radius: 8px;
                margin: 20px 0;
            }
            .auto-refresh {
                text-align: center;
                color: #6b7280;
                font-size: 0.9em;
                margin-top: 30px;
                padding: 10px;
                background: #f9fafb;
                border-radius: 8px;
            }
            .command-box {
                background: #1f2937;
                color: #f9fafb;
                padding: 12px;
                border-radius: 6px;
                font-family: 'Courier New', monospace;
                margin: 10px 0;
                font-size: 0.95em;
            }
            .subscriber-status {
                display: flex;
                align-items: center;
                gap: 8px;
                font-weight: 700;
                margin-bottom: 12px;
            }
            .subscriber-actions {
                display: flex;
                gap: 8px;
                flex-wrap: wrap;
                margin-top: 14px;
            }
            .subscriber-button {
                display: inline-flex;
                align-items: center;
                gap: 6px;
                border: 1px solid #d1d5db;
                background: white;
                color: #374151;
                padding: 8px 14px;
                border-radius: 8px;
                cursor: pointer;
                font-weight: 600;
                text-decoration: none;
            }
            .subscriber-button:hover { background: #f3f4f6; }
            .subscriber-label {
                margin-top: 12px;
                color: #4b5563;
                font-weight: 700;
            }
            .activity-toolbar {
                display: flex;
                gap: 8px;
                flex-wrap: wrap;
                align-items: center;
                margin: 0 0 15px 0;
            }
            .activity-limit-label {
                display: inline-flex;
                align-items: center;
                gap: 8px;
                margin-left: auto;
                color: #4b5563;
                font-weight: 600;
            }
            .activity-limit {
                width: auto;
                min-width: 90px;
                border: 1px solid #d1d5db;
                background: white;
                color: #374151;
                padding: 8px 10px;
                border-radius: 8px;
                font-weight: 600;
            }
            .activity-clear {
                border: 1px solid #fecaca;
                background: #fff;
                color: #b91c1c;
                padding: 8px 14px;
                border-radius: 8px;
                cursor: pointer;
                font-weight: 600;
            }
            .activity-clear:hover {
                background: #fef2f2;
            }
            .activity-filter {
                border: 1px solid #d1d5db;
                background: white;
                color: #374151;
                padding: 8px 14px;
                border-radius: 999px;
                cursor: pointer;
                font-weight: 600;
            }
            .activity-filter.active {
                background: #4f46e5;
                border-color: #4f46e5;
                color: white;
            }
            .activity-empty {
                display: none;
                text-align: center;
                padding: 30px 20px;
                color: #9ca3af;
                border: 1px dashed #d1d5db;
                border-radius: 12px;
            }
            .activity-item.verification-flow {
                border-left: 5px solid #3b82f6;
                background: #f8fbff;
            }
            .activity-item.notification-flow {
                border-left: 5px solid #22c55e;
                background: #f7fef9;
            }
            .flow-banner {
                margin-top: 10px;
                padding: 10px 12px;
                border-radius: 8px;
                font-weight: 700;
            }
            .flow-banner.verification {
                background: #dbeafe;
                color: #1e40af;
            }
            .flow-banner.notification {
                background: #dcfce7;
                color: #166534;
            }
            .flow-source {
                float: right;
                font-weight: 500;
            }
            .exchange-grid {
                display: grid;
                grid-template-columns: repeat(2, minmax(0, 1fr));
                gap: 12px;
                align-items: stretch;
                margin-top: 10px;
            }
            .exchange-column {
                display: flex;
                flex-direction: column;
                min-width: 0;
            }
            .exchange-column pre {
                flex: 1;
                width: 100%;
            }
            @media (max-width: 820px) {
                .exchange-grid { grid-template-columns: 1fr; }
                .flow-source { float: none; display: block; margin-top: 6px; }
            }
            .verification-card {
                margin-top: 10px;
                padding: 10px 12px;
                border-radius: 8px;
            }
            .verification-meta {
                display: flex;
                gap: 18px;
                flex-wrap: wrap;
                margin-top: 8px;
                font-size: 0.9em;
            }
        </style>
    </head>
    <body>
        <div class="container">
            <h1>📡 Webhook Dashboard</h1>
            <div class="subtitle">Real-time webhook monitoring</div>
            
            <div id="subscriberSetup"></div>
            
            <div class="stats">
                <div class="stat-item">
                    <div class="stat-number"><span id="notificationCount">${getActivityStats().notifications}</span></div>
                    <div class="stat-label">Notifications</div>
                </div>
                <div class="stat-item">
                    <div class="stat-number"><span id="verificationCount">${getActivityStats().verifications}</span></div>
                    <div class="stat-label">Verification Requests</div>
                </div>
                <div class="stat-item">
                    <div class="stat-number">${receivedWebhooks.length}</div>
                    <div class="stat-label">Total Activity</div>
                </div>
            </div>          
                        
            <h2>📨 Webhook Activity</h2>
            <div class="activity-toolbar" aria-label="Webhook activity filter">
                <button type="button" class="activity-filter active" data-filter="all">All</button>
                <button type="button" class="activity-filter" data-filter="verification">Verifications</button>
                <button type="button" class="activity-filter" data-filter="notification">Notifications</button>
                <label class="activity-limit-label" for="activityLimit">
                    Show
                    <select id="activityLimit" class="activity-limit">
                        <option value="10">10</option>
                        <option value="25">25</option>
                        <option value="50">50</option>
                        <option value="100">100</option>
                        <option value="all">All</option>
                    </select>
                </label>
                <button type="button" id="clearActivity" class="activity-clear">Clear Activity</button>
            </div>

            <div id="activityList">${renderActivityHtml()}</div>
            <div id="activityFilterEmpty" class="activity-empty">No activity matches this filter.</div>

            <div class="auto-refresh">
                🔄 Live activity updates every 5 seconds
            </div>
        </div>
        
        <script>
            const FILTER_STORAGE_KEY = 'webhook-dashboard-activity-filter';
            const LIMIT_STORAGE_KEY = 'webhook-dashboard-activity-limit';
            const filterButtons = Array.from(document.querySelectorAll('.activity-filter'));
            const filterEmpty = document.getElementById('activityFilterEmpty');
            const activityLimit = document.getElementById('activityLimit');
            const clearActivity = document.getElementById('clearActivity');
            const activityList = document.getElementById('activityList');
            const notificationCount = document.getElementById('notificationCount');
            const verificationCount = document.getElementById('verificationCount');
            const totalActivityCount = document.getElementById('totalActivityCount');
            const subscriberSetup = document.getElementById('subscriberSetup');
            let activitySignature = '';
            let refreshInProgress = false;

            function escapeClientHtml(value) {
                return String(value == null ? '' : value)
                    .replace(/&/g, '&amp;')
                    .replace(/</g, '&lt;')
                    .replace(/>/g, '&gt;')
                    .replace(/"/g, '&quot;')
                    .replace(/'/g, '&#39;');
            }

            async function copyText(value, button) {
                try {
                    await navigator.clipboard.writeText(String(value || ''));
                    if (button) {
                        const original = button.textContent;
                        button.textContent = '✓ Copied';
                        setTimeout(() => { button.textContent = original; }, 1400);
                    }
                } catch (error) {
                    alert('Copy failed: ' + (error.message || error));
                }
            }

            function renderNgrokStatus(status) {
                if (!subscriberSetup) return;

                if (!status || !status.running || !status.publicUrl) {
                    subscriberSetup.innerHTML = [
                        '<div class="setup-box">',
                        '<h3 style="margin:0 0 12px 0;">Subscriber Required</h3>',
                        '<div class="subscriber-status">🔴 ngrok is not running</div>',
                        '<p><strong>1.</strong> Start ngrok:</p>',
                        '<div class="command-box">ngrok http 3000</div>',
                        '<div class="subscriber-actions">',
                        '<button type="button" class="subscriber-button" id="copyNgrokCommand">📋 Copy command</button>',
                        '<a class="subscriber-button" href="http://127.0.0.1:4040" target="_blank" rel="noopener">🔗 ngrok dashboard</a>',
                        '</div>',
                        '</div>'
                    ].join('');
                    const copyButton = document.getElementById('copyNgrokCommand');
                    if (copyButton) copyButton.addEventListener('click', () => copyText('ngrok http 3000', copyButton));
                    return;
                }

                const publicUrl = String(status.publicUrl).replace(/\\/+$/, '');
                const subscriberEndpoint = publicUrl + '/webhook';
                subscriberSetup.innerHTML = [
                    '<div class="tunnel-info">',
                    '<h3 style="margin:0 0 12px 0;">Subscriber Endpoint</h3>',
                    '<div class="subscriber-status">🟢 ngrok is running</div>',
                    '<div class="subscriber-label">Public URL</div>',
                    '<div class="tunnel-url">' + escapeClientHtml(publicUrl) + '</div>',
                    '<div class="subscriber-label">Subscriber endpoint</div>',
                    '<div class="tunnel-url">' + escapeClientHtml(subscriberEndpoint) + '</div>',
                    '<div class="subscriber-actions">',                    
                    '<a class="subscriber-button" href="http://127.0.0.1:4040" target="_blank" rel="noopener">🔗 ngrok dashboard</a>',
					'<button type="button" class="subscriber-button" id="copyPublicUrl">📋 Copy endpoint</button>',                    
                    '</div>',
                    '</div>'
                ].join('');

                const publicButton = document.getElementById('copyPublicUrl');
                const subscriberButton = document.getElementById('copySubscriberEndpoint');
                if (publicButton) publicButton.addEventListener('click', () => copyText(publicUrl, publicButton));
                if (subscriberButton) subscriberButton.addEventListener('click', () => copyText(subscriberEndpoint, subscriberButton));
            }

            async function refreshNgrokStatus() {
                try {
                    const response = await fetch('/ngrok-status', {
                        headers: { Accept: 'application/json' },
                        cache: 'no-store'
                    });
                    if (!response.ok) throw new Error('HTTP ' + response.status);
                    renderNgrokStatus(await response.json());
                } catch (error) {
                    renderNgrokStatus({ running: false, publicUrl: null });
                }
            }

            function getActivityItems() {
                return Array.from(document.querySelectorAll('.activity-item'));
            }

            function getSelectedLimit() {
                const raw = activityLimit ? activityLimit.value : '10';
                return raw === 'all' ? Infinity : Number(raw || 10);
            }

            function applyActivityFilter(filter) {
                const normalized = ['all', 'verification', 'notification'].includes(filter) ? filter : 'all';
                const limit = getSelectedLimit();
                const activityItems = getActivityItems();
                let shown = 0;

                filterButtons.forEach(button => {
                    button.classList.toggle('active', button.dataset.filter === normalized);
                });

                activityItems.forEach(item => {
                    const matches = normalized === 'all' || item.dataset.activityType === normalized;
                    const visible = matches && shown < limit;
                    item.style.display = visible ? '' : 'none';
                    if (visible) shown++;
                });

                if (filterEmpty) {
                    filterEmpty.style.display = activityItems.length > 0 && shown === 0 ? 'block' : 'none';
                }

                localStorage.setItem(FILTER_STORAGE_KEY, normalized);
            }

            async function refreshActivity(force = false) {
                if (refreshInProgress) return;
                refreshInProgress = true;
                try {
                    const response = await fetch('/activity', {
                        headers: { Accept: 'application/json' },
                        cache: 'no-store'
                    });
                    if (!response.ok) throw new Error('HTTP ' + response.status);
                    const data = await response.json();

                    if (notificationCount) notificationCount.textContent = String(data.stats.notifications);
                    if (verificationCount) verificationCount.textContent = String(data.stats.verifications);
                    if (totalActivityCount) totalActivityCount.textContent = String(data.stats.total);

                    if (force || data.signature !== activitySignature) {
                        activitySignature = data.signature;
                        if (activityList) activityList.innerHTML = data.html;
                        applyActivityFilter(localStorage.getItem(FILTER_STORAGE_KEY) || 'all');
                    }
                } catch (error) {
                    console.warn('Activity refresh failed:', error);
                } finally {
                    refreshInProgress = false;
                }
            }

            filterButtons.forEach(button => {
                button.addEventListener('click', () => applyActivityFilter(button.dataset.filter));
            });

            if (activityLimit) {
                const rememberedLimit = localStorage.getItem(LIMIT_STORAGE_KEY) || '10';
                activityLimit.value = ['10', '25', '50', '100', 'all'].includes(rememberedLimit)
                    ? rememberedLimit
                    : '10';
                activityLimit.addEventListener('change', () => {
                    localStorage.setItem(LIMIT_STORAGE_KEY, activityLimit.value);
                    applyActivityFilter(localStorage.getItem(FILTER_STORAGE_KEY) || 'all');
                });
            }

            if (clearActivity) {
                clearActivity.addEventListener('click', async () => {
                    if (!confirm('Clear all webhook activity from this listener session?')) return;
                    clearActivity.disabled = true;
                    try {
                        const response = await fetch('/clear-activity', { method: 'POST' });
                        if (!response.ok) throw new Error('HTTP ' + response.status);
                        await refreshActivity(true);
                    } catch (error) {
                        alert('Could not clear activity: ' + (error.message || error));
                    } finally {
                        clearActivity.disabled = false;
                    }
                });
            }

            applyActivityFilter(localStorage.getItem(FILTER_STORAGE_KEY) || 'all');
            refreshActivity(true);
            refreshNgrokStatus();
            setInterval(refreshActivity, 5000);
            setInterval(refreshNgrokStatus, 30000);
        </script>
    </body>
    </html>`;
    
    res.send(html);
});

// Handle POST requests to root path
app.post('/', (req, res) => {
    console.log('\n' + '='.repeat(80));
    console.log('📨 WEBHOOK NOTIFICATION RECEIVED');
    console.log('='.repeat(80));
    console.log(`📅 Timestamp: ${new Date().toISOString()}`);
    
    console.log('\n📦 WEBHOOK PAYLOAD:');
    console.log(JSON.stringify(req.body, null, 2));
	
	console.log('\n📋 REQUEST HEADERS:');
	console.log(JSON.stringify(req.headers, null, 2));
    
    const responseBody = {
        status: 'received',
        message: 'Webhook processed successfully',
        timestamp: new Date().toISOString()
    };

    // Store the complete request/response exchange
    const webhookData = {
        timestamp: new Date().toISOString(),
        type: 'notification',
        method: req.method,
        path: req.originalUrl || req.path,
        request: {
            method: req.method,
            path: req.originalUrl || req.path,
            headers: { ...req.headers },
            body: req.body
        },
        response: {
            status: 200,
            statusText: 'OK',
            headers: { 'Content-Type': 'application/json; charset=utf-8' },
            body: responseBody
        },
        sourceIp: req.headers['x-forwarded-for'] || req.socket.remoteAddress
    };

    receivedWebhooks.push(webhookData);

    // Process the notification
    if (req.body && req.body.Topic) {
        console.log(`\n🔍 PARSED DATA:`);
        console.log(`   🎯 Event Type: "${req.body.Topic}"`);
        console.log(`   🏢 Node ID: "${req.body.Node}"`);
        console.log(`   🎯 Target ID: "${req.body.Target}"`);
        if (req.body.Employee) {
            console.log(`   👤 Employee ID: "${req.body.Employee}"`);
        }
    }
    
    res.status(200).json(responseBody);
    
    console.log('\n🎉 WEBHOOK PROCESSED!');
    console.log('='.repeat(80) + '\n');
});

// Webhook endpoints (alternative paths)
app.get('/webhook', handleVerification);

app.post('/webhook', (req, res) => {
    const timestamp = new Date().toISOString();
    const responseBody = {
        status: 'received',
        message: 'Webhook processed successfully'
    };

    console.log('\n' + '='.repeat(80));
    console.log('📨 WEBHOOK NOTIFICATION RECEIVED AT /webhook');
    console.log('='.repeat(80));
    console.log(`📅 Timestamp: ${timestamp}`);
    console.log('\n📦 WEBHOOK PAYLOAD:');
    console.log(JSON.stringify(req.body, null, 2));
    console.log('\n📋 REQUEST HEADERS:');
    console.log(JSON.stringify(req.headers, null, 2));

    receivedWebhooks.push({
        timestamp,
        type: 'notification',
        method: req.method,
        path: req.originalUrl || req.path,
        request: {
            method: req.method,
            path: req.originalUrl || req.path,
            headers: { ...req.headers },
            body: req.body
        },
        response: {
            status: 200,
            statusText: 'OK',
            headers: { 'Content-Type': 'application/json; charset=utf-8' },
            body: responseBody
        },
        sourceIp: req.headers['x-forwarded-for'] || req.socket.remoteAddress
    });

    res.status(200).json(responseBody);

    console.log('\n🎉 WEBHOOK PROCESSED!');
    console.log('='.repeat(80) + '\n');
});

// Return local ngrok tunnel status
app.get('/ngrok-status', async (req, res) => {
    res.set('Cache-Control', 'no-store');
    res.status(200).json(await getNgrokStatus());
});

// Return activity updates without reloading the dashboard page
app.get('/activity', (req, res) => {
    res.set('Cache-Control', 'no-store');
    res.status(200).json({
        signature: getActivitySignature(),
        stats: getActivityStats(),
        html: renderActivityHtml()
    });
});

// Clear in-memory activity history
app.post('/clear-activity', (req, res) => {
    const cleared = receivedWebhooks.length;
    receivedWebhooks = [];
    res.status(200).json({
        status: 'cleared',
        cleared
    });
});

// Test ping endpoint
app.get('/ping-test', (req, res) => {
    res.json({
        status: 'Server is running',
        timestamp: new Date().toISOString(),
        url: req.get('host')
    });
});

// Catch-all route
app.use((req, res) => {
    console.log('\n🚨 CATCH-ALL ROUTE HIT');
    console.log(`Method: ${req.method}`);
    console.log(`Path: ${req.path}`);
    if (req.body && Object.keys(req.body).length > 0) {
        console.log('Body:', JSON.stringify(req.body, null, 2));
    }
    
    receivedWebhooks.push({
        timestamp: new Date().toISOString(),
        method: req.method,
        path: req.path,
        headers: req.headers,
        body: req.body
    });
    
    res.status(200).json({
        message: 'Request captured',
        method: req.method,
        path: req.path
    });
});

// Start server
app.listen(PORT, () => {
    console.log('\n' + '='.repeat(60));
    console.log('🚀 Webhook Test Server Running!');
    console.log('='.repeat(60));
    console.log(`\n📊 Local Dashboard: http://localhost:${PORT}`);
    console.log(`\n📋 Next Steps:`);
    console.log('\n1️⃣  Open a SECOND terminal and run ngrok:\n');
    
    console.log('   🟢 ngrok');
    console.log('   ─────────────────────────────────────');
    console.log('   First time? Use Global install:	npm install -g ngrok');
	console.log('   ngrok http 3000 or npx ngrok http 3000 (no installation)');    
	    
    console.log('\n2️⃣  Copy the tunnel URL from the second terminal');
    console.log('3️⃣  Register that URL as your webhook endpoint');
    console.log('4️⃣  Test by triggering events in Manus');
    
    console.log('\n🔍 Watching for webhooks...\n');
    console.log('='.repeat(60) + '\n');
});