const express = require('express');
const app = express();
const PORT = 3000;

// Store received data for inspection
let receivedWebhooks = [];
let manualTunnelUrl = null;

// Parse JSON BEFORE logging middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Enhanced logging middleware
app.use((req, res, next) => {
    const timestamp = new Date().toISOString();
    
    if (req.path !== '/ping-test' && req.path !== '/dashboard') {
        console.log(`\n📡 ${req.method} ${req.path} - ${timestamp}`);
        // Remove the PARSED BODY section since it's shown in the POST handler
    }
    
    next();
});

// Verification handler function
const handleVerification = (req, res) => {
    console.log('\n' + '='.repeat(80));
    console.log('🔐 WEBHOOK VERIFICATION REQUEST');
    console.log('='.repeat(80));
    
    const hookSecret = req.headers['x-hook-secret'];
    
    if (hookSecret) {
        console.log(`✅ X-Hook-Secret found: "${hookSecret}"`);
        res.set('X-Hook-Secret', hookSecret);
        res.status(200).send('Webhook verification successful');
        console.log(`🎉 Verification completed successfully!`);
    } else {
        console.log(`❌ Missing X-Hook-Secret header`);
        res.status(400).send('Missing X-Hook-Secret header');
    }
    
    console.log('='.repeat(80) + '\n');
};

// Root path handler
app.get('/', (req, res) => {
    if (req.headers['x-hook-secret']) {
        return handleVerification(req, res);
    }
    
    const html = `
    <!DOCTYPE html>
    <html>
    <head>
        <title>Webhook Test Dashboard</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <style>
            * { margin: 0; padding: 0; box-sizing: border-box; }
            body { 
                font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, sans-serif;
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                min-height: 100vh;
                padding: 20px;
            }
            .container { 
                max-width: 1200px; 
                margin: 0 auto; 
                background: white; 
                padding: 30px; 
                border-radius: 16px;
                box-shadow: 0 20px 60px rgba(0,0,0,0.3);
            }
            h1 { 
                color: #333; 
                margin-bottom: 10px;
                font-size: 2em;
            }
            .subtitle {
                color: #666;
                margin-bottom: 30px;
                font-size: 1.1em;
            }
            .stats { 
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                color: white;
                padding: 20px; 
                border-radius: 12px; 
                margin: 20px 0;
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
                gap: 20px;
            }
            .stat-item {
                text-align: center;
            }
            .stat-number {
                font-size: 2.5em;
                font-weight: bold;
                margin-bottom: 5px;
            }
            .stat-label {
                font-size: 0.9em;
                opacity: 0.9;
            }
            .tunnel-info {
                background: #f0f9ff;
                border-left: 4px solid #0ea5e9;
                padding: 15px;
                border-radius: 8px;
                margin: 20px 0;
            }
            .tunnel-url {
                font-family: 'Courier New', monospace;
                font-size: 1.1em;
                color: #0369a1;
                word-break: break-all;
                margin-top: 5px;
            }
            .setup-box {
                background: #fef3c7;
                border-left: 4px solid #f59e0b;
                padding: 15px;
                border-radius: 8px;
                margin: 20px 0;
            }
            .setup-box code {
                background: #fff;
                padding: 2px 6px;
                border-radius: 4px;
                font-family: 'Courier New', monospace;
                font-size: 0.9em;
            }
            .webhook { 
                border: 1px solid #e5e7eb; 
                margin: 15px 0; 
                padding: 20px; 
                border-radius: 12px; 
                background: #fafafa;
                transition: transform 0.2s, box-shadow 0.2s;
            }
            .webhook:hover {
                transform: translateY(-2px);
                box-shadow: 0 4px 12px rgba(0,0,0,0.1);
            }
            .timestamp { 
                color: #6b7280; 
                font-size: 0.9em; 
                margin-bottom: 10px;
                display: flex;
                align-items: center;
                gap: 5px;
            }
            .method-badge {
                display: inline-block;
                padding: 4px 12px;
                border-radius: 20px;
                font-size: 0.85em;
                font-weight: 600;
                margin-right: 10px;
            }
            .method-POST {
                background: #dcfce7;
                color: #166534;
            }
            .method-GET {
                background: #dbeafe;
                color: #1e40af;
            }
            pre { 
                background: #1f2937; 
                color: #f9fafb;
                padding: 15px; 
                overflow-x: auto; 
                border-radius: 8px;
                font-size: 0.9em;
                margin-top: 10px;
                max-height: 400px;
            }
            .no-webhooks {
                text-align: center;
                padding: 60px 20px;
                color: #9ca3af;
            }
            .no-webhooks-icon {
                font-size: 4em;
                margin-bottom: 20px;
            }
            h2 { 
                color: #1f2937; 
                margin: 30px 0 15px 0;
                font-size: 1.5em;
                border-bottom: 2px solid #e5e7eb;
                padding-bottom: 10px;
            }
            .info-box {
                background: #e0f2fe;
                border-left: 4px solid #0ea5e9;
                padding: 15px;
                border-radius: 8px;
                margin: 20px 0;
            }
            .auto-refresh {
                text-align: center;
                color: #6b7280;
                font-size: 0.9em;
                margin-top: 30px;
                padding: 10px;
                background: #f9fafb;
                border-radius: 8px;
            }
            .command-box {
                background: #1f2937;
                color: #f9fafb;
                padding: 12px;
                border-radius: 6px;
                font-family: 'Courier New', monospace;
                margin: 10px 0;
                font-size: 0.95em;
            }
        </style>
    </head>
    <body>
        <div class="container">
            <h1>📡 Webhook Test Dashboard</h1>
            <div class="subtitle">Real-time webhook monitoring and debugging</div>
            
            ${!manualTunnelUrl ? `
            <div class="setup-box">
                <strong>⚠️ Setup Required:</strong><br>
                Open a second terminal and run one of these commands:<br><br>
                <strong>🔵 LocalTunnel (same URL each time):</strong>
                <div class="command-box">npx localtunnel --port 3000 --subdomain your-unique-name</div>
                
                <strong>🟢 ngrok (best dashboard):</strong>
                <div class="command-box">ngrok http 3000</div>
                <small>Then visit <a href="http://127.0.0.1:4040" target="_blank">http://127.0.0.1:4040</a> for the ngrok dashboard!</small>
            </div>
            ` : `
            <div class="tunnel-info">
                <strong>🌐 Your Public URL:</strong>
                <div class="tunnel-url">${manualTunnelUrl}</div>
            </div>
            `}
            
            <div class="stats">
                <div class="stat-item">
                    <div class="stat-number">${receivedWebhooks.length}</div>
                    <div class="stat-label">Total Webhooks</div>
                </div>
                <div class="stat-item">
                    <div class="stat-number">${receivedWebhooks.filter(w => w.method === 'POST').length}</div>
                    <div class="stat-label">POST Requests</div>
                </div>
                <div class="stat-item">
                    <div class="stat-number">${receivedWebhooks.filter(w => w.method === 'GET').length}</div>
                    <div class="stat-label">GET Requests</div>
                </div>
            </div>
            
            <div class="info-box">
                💡 <strong>Pro Tips:</strong>
                <ul style="margin: 10px 0 0 20px;">
                    <li>Using ngrok? Visit <a href="http://127.0.0.1:4040" target="_blank">http://127.0.0.1:4040</a> for advanced request inspection and replay!</li>
                    <li>This dashboard auto-refreshes every 5 seconds</li>
                    <li>Check your terminal for detailed webhook logs</li>
                </ul>
            </div>
            
            <h2>📨 Recent Webhooks (Last 10)</h2>
            ${receivedWebhooks.length > 0 ? receivedWebhooks.slice(-10).reverse().map(webhook => `
                <div class="webhook">
                    <div class="timestamp">
                        ⏰ ${webhook.timestamp}
                    </div>
                    <div>
                        <span class="method-badge method-${webhook.method || 'POST'}">${webhook.method || 'POST'}</span>
                        <strong>Path:</strong> ${webhook.path || '/'}
                    </div>
                    ${webhook.body && Object.keys(webhook.body).length > 0 ? `
                        <div style="margin-top: 10px;">
                            <strong>📦 Payload:</strong>
                            <pre>${JSON.stringify(webhook.body, null, 2)}</pre>
                        </div>
                    ` : '<div style="margin-top: 10px; color: #9ca3af;"><em>No body data</em></div>'}
                </div>
            `).join('') : `
                <div class="no-webhooks">
                    <div class="no-webhooks-icon">📭</div>
                    <h3>No webhooks received yet</h3>
                    <p style="margin-top: 10px;">Waiting for incoming webhook notifications...</p>
                    <p style="margin-top: 5px; font-size: 0.9em;">Make sure you've set up a tunnel (see yellow box above)</p>
                </div>
            `}
            
            <div class="auto-refresh">
                🔄 Auto-refreshing every 5 seconds...
            </div>
        </div>
        
        <script>
            setTimeout(() => location.reload(), 5000);
        </script>
    </body>
    </html>`;
    
    res.send(html);
});

// Handle POST requests to root path
app.post('/', (req, res) => {
    console.log('\n' + '='.repeat(80));
    console.log('📨 WEBHOOK NOTIFICATION RECEIVED');
    console.log('='.repeat(80));
    console.log(`📅 Timestamp: ${new Date().toISOString()}`);
    
    console.log('\n📦 WEBHOOK PAYLOAD:');
    console.log(JSON.stringify(req.body, null, 2));
    
    // Store the webhook data
    const webhookData = {
        timestamp: new Date().toISOString(),
        method: 'POST',
        path: req.path,
        headers: req.headers,
        body: req.body,
        sourceIp: req.headers['x-forwarded-for'] || req.connection.remoteAddress
    };
    
    receivedWebhooks.push(webhookData);
    
    // Process the notification
    if (req.body && req.body.Topic) {
        console.log(`\n🔍 PARSED DATA:`);
        console.log(`   🎯 Event Type: "${req.body.Topic}"`);
        console.log(`   🏢 Node ID: "${req.body.Node}"`);
        console.log(`   🎯 Target ID: "${req.body.Target}"`);
        if (req.body.Employee) {
            console.log(`   👤 Employee ID: "${req.body.Employee}"`);
        }
    }
    
    res.status(200).json({ 
        status: 'received', 
        message: 'Webhook processed successfully',
        timestamp: new Date().toISOString()
    });
    
    console.log('\n🎉 WEBHOOK PROCESSED!');
    console.log('='.repeat(80) + '\n');
});

// Webhook endpoints (alternative paths)
app.get('/webhook', handleVerification);

app.post('/webhook', (req, res) => {
    console.log('\n📨 WEBHOOK at /webhook');
    console.log('Payload:', JSON.stringify(req.body, null, 2));
    
    receivedWebhooks.push({
        timestamp: new Date().toISOString(),
        method: 'POST',
        path: '/webhook',
        headers: req.headers,
        body: req.body
    });
    
    res.status(200).json({ 
        status: 'received', 
        message: 'Webhook processed successfully' 
    });
});

// Test ping endpoint
app.get('/ping-test', (req, res) => {
    res.json({
        status: 'Server is running',
        timestamp: new Date().toISOString(),
        url: req.get('host')
    });
});

// Catch-all route
app.use((req, res) => {
    console.log('\n🚨 CATCH-ALL ROUTE HIT');
    console.log(`Method: ${req.method}`);
    console.log(`Path: ${req.path}`);
    if (req.body && Object.keys(req.body).length > 0) {
        console.log('Body:', JSON.stringify(req.body, null, 2));
    }
    
    receivedWebhooks.push({
        timestamp: new Date().toISOString(),
        method: req.method,
        path: req.path,
        headers: req.headers,
        body: req.body
    });
    
    res.status(200).json({
        message: 'Request captured',
        method: req.method,
        path: req.path
    });
});

// Start server
app.listen(PORT, () => {
    console.log('\n' + '='.repeat(60));
    console.log('🚀 Webhook Test Server Running!');
    console.log('='.repeat(60));
    console.log(`\n📊 Local Dashboard: http://localhost:${PORT}`);
    console.log(`\n📋 Next Steps:`);
    console.log('\n1️⃣  Open a SECOND terminal and run ONE of these:\n');
    
    console.log('   🔵 LocalTunnel (same URL each time):');
    console.log('   ─────────────────────────────────────');
    console.log('   npx localtunnel --port 3000 --subdomain your-unique-name');
    console.log('   Example: npx localtunnel --port 3000 --subdomain jeroen-manus-webhook\n');
    
    console.log('   🟢 ngrok (best dashboard):');
    console.log('   ─────────────────────────────────────');
    console.log('   ngrok http 3000 or npx ngrok http 3000 (no installation)');
    console.log('   Then visit: http://127.0.0.1:4040 (ngrok web dashboard)');
	console.log('   First time? Use Global install:	npm install -g ngrok');
    
    console.log('\n2️⃣  Copy the tunnel URL from the second terminal');
    console.log('3️⃣  Register that URL as your webhook endpoint');
    console.log('4️⃣  Test by triggering events in your system');
    
    console.log('\n🔍 Watching for webhooks...\n');
    console.log('='.repeat(60) + '\n');
});